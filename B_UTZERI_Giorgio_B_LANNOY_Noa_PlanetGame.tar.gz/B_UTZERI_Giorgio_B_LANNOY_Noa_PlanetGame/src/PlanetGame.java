import extensions.CSVFile;

class PlanetGame extends Program {
    String prenomSauvegarde = "";
    final char SL = '\n';
    String commande;
    boolean jeuEnCours = true;
    final int NB_COLS_MEMORY = 4;
    final int NB_LIGS_MEMORY = 4;
    
    void algorithm(){
        menuAccueil();
    }

    /* permet de convertir un fichier texte dans ressources/ en String */
    String lireTxt(String NomFichier){
        String result = "";
        for(int IDX_LIGNE=0; IDX_LIGNE<rowCount(loadCSV("ressources/"+NomFichier)); IDX_LIGNE++){
            result += getCell(loadCSV("ressources/"+NomFichier), IDX_LIGNE, 0) + SL; 
        }
        return result;
    }

    /* Permet d'afficher le menu d'accueil et demande un nombre pour rediriger vers la demande */
    void menuAccueil(){
        jeuEnCours = true;
        while(jeuEnCours){
        println(lireTxt("NomJeu.txt"));
        int NumeroChoisi = -1;
        while(1> NumeroChoisi || NumeroChoisi>4){
            println(SL + "Que veux tu faire ? Merci de chosir un nombre entre 1 et 4");
            NumeroChoisi = readInt();
        }
        if(NumeroChoisi == 1){
            niveau1();
            jeuEnCours = false;
        } else if (NumeroChoisi == 2){
            menuReprise();
            jeuEnCours = false;
        } else if (NumeroChoisi == 3){
            classement();
            jeuEnCours = false;
        } else if (NumeroChoisi == 4){
            jeuEnCours = false;
        }
        }
        
    }

    /* Permet de demander l'identifiant d'une partie pour le renvoyer dedans si elle n'était pas finit */
    void menuReprise(){
        jeuEnCours = true;
        while(jeuEnCours){
            println(lireTxt("Continuer.txt"));
            String identifiant = readString();

            /* RAJOUTER FONCTION QUI CHERCHE LIDENTIFIANT DANS LA BDD DES PARTIES ET REPREND LA PARTIE SI FINIT=FALSE */

            if(equals(identifiant, "QUITTER")){
                jeuEnCours = false;
            }
        }
    }

    /* Permet d'afficher un tableau de toutes les parties avec l'identifiant et le nombre de points trier par odre décroissant */
    void classement(){
        jeuEnCours = true;
        while(jeuEnCours){
            println(lireTxt("classement.txt"));
            String quitter = readString();

            /* RAJOUTER FONCTION QUI AFFICHER UN TABLEAU DE TOUTES LES PARTIES TRIER PAR ORDRE DECROISSANT DU NOMBRE DE POINT */

            if(equals(quitter, "QUITTER")){
                jeuEnCours = false;
            }
        }
    }

    /* Permet de permutter une ligne d'une liste par une autre */
    void permuterLigne(String[] liste, int ligneA, int ligneB){
        String tmp = liste[ligneA];
        liste[ligneA] = liste[ligneB];
        liste[ligneB] = tmp;
    }

    /* Permet de convertir une liste entière en String séparer par des espaces */
	String toString(String[] liste){
		String tmp = "";
        for(int i = 0; i<length(liste); i++){
            tmp = tmp + liste[i] + " ";
        }
        return tmp;
	}

    /* Permet de trier la liste de toutes les planètes aléatoirement */
    String[] initialiserListe(){
        String[] ListePlanete = new String[]{"MERCURE","VENUS", "TERRE", "MARS", "JUPITER", "SATURNE", "URANUS", 
        "NEPTUNE", "MERCURE", "VENUS", "TERRE", "MARS", "JUPITER", "SATURNE", "URANUS", "NEPTUNE"};
        for (int IDX = length(ListePlanete)-1; IDX>0; IDX--){
            int aleaListe = (int)(random()*length(ListePlanete));
            permuterLigne(ListePlanete, IDX, aleaListe);
        }
        return ListePlanete;
    }  

    /* Permet d'initialier le tableau du niveau 1 avec les planètes aléatoirement */
    void initialiser(MemoryGame[][] memory){
        String[] ListePlanete = initialiserListe();
        int IDX_LISTE = 0;
        for(int l=0;l<length(memory,1); l++){
            for(int c=0;c<length(memory,2); c++){
                memory[l][c]=newPlanete(ListePlanete[IDX_LISTE]);
                IDX_LISTE+=1;
            }
        }
    }

    /* Permet de créer une planete avec la valeur mit en paramètre */
    MemoryGame newPlanete(String plan){
        MemoryGame p = new MemoryGame();
        p.decouverte=false;
        p.planete=plan;
        return p;
    }

    boolean testerDecouverte(MemoryGame[][] Memory){
        //true == pas découvertes
        int IDX_L = 0;
        boolean result = true;
        while(IDX_L < length(Memory, 1) && result){
            int IDX_C = 0;
            while(IDX_C < length(Memory, 2) && result){
                if(Memory[IDX_L][IDX_C].decouverte==false){
                    result = false;
                }
                IDX_C += 1;
            }
            IDX_L += 1;
        }

        return !result;
    }   

    String calculeTableau(int longueur, char car){
        String res = "";
        for (int IDX=0; IDX<longueur; IDX++){
            res+=car;
        }
        return res;
    } 

    int maxLigne(MemoryGame[][] tab){
        int res = 0;
        for (int l=0; l<length(tab,1); l++){
            int n_res=0;
            for(int c=0; c<length(tab,2); c++){
                n_res+=length(tab[l][c].planete);
            }
            if(n_res>res){
                res=n_res;
            }
        }
        return res;
    }

    String premiereLigneTableau(){
        String res = "";
        for(int IDX=1; IDX<5; IDX++){
            res+= calculeTableau(4, '=') + " " + IDX + " " + calculeTableau(3, '=');
        }
        res += "=";
        return res;
    }
    
    String texte(MemoryGame[][] tab){
		String res = "";
        char[] ListeLettre = new char[]{'A', 'B', 'C', 'D'};
        res+= "   " + premiereLigneTableau() + SL; 
		for (int l=0;l<length(tab,1);l++){
            res += ListeLettre[l] + " ";
			for (int c=0;c<length(tab,2);c++){
                if(c==0){
                    res+= " | ";
                }
				res = res + texte(tab[l][c]) + " ";
                res+="| ";
			}	    
			res+= "\n";
            res+= "   " + calculeTableau((maxLigne(tab)+15), '=') + SL;  
		}
		return res;
    }
    
    /* Retourne la chaîne de caractère prête à être affichée qui correspond au poisson passé en paramètre */
    String texte(MemoryGame p){
        if(p.decouverte==false){
			return "~~~~~~~";
		}else{
			return p.planete + genererEspace(p.planete);
		}
    }

    String genererEspace(String planete){
        String res = "";
        for(int IDX_M = 7; IDX_M>length(planete); IDX_M--){
            res+=" ";
        }
        return res;
    }
    
    /* Permet d'afficher et de jouer au niveau 1 */
    void niveau1(){
        jeuEnCours = true;
        MemoryGame[][] Memory = new MemoryGame[NB_LIGS_MEMORY][NB_COLS_MEMORY];
        initialiser(Memory);
        
        
        while(testerDecouverte(Memory) && jeuEnCours){
            clearScreen();
            println(lireTxt("Memory.txt"));
            println(texte(Memory));
            println("Première carte");
            int[] ValeursA = demandeCarte(Memory);
            retournerCarte(Memory, ValeursA[0], ValeursA[1]);
            println(texte(Memory));
            println("Deuxième carte");
            int[] ValeursB = demandeCarte(Memory);
            retournerCarte(Memory, ValeursB[0], ValeursB[1]);
            println(texte(Memory));
            if(!(sontLesMemes(Memory, ValeursA, ValeursB))){
                cacherCarte(Memory, ValeursA[0], ValeursA[1]);
                cacherCarte(Memory, ValeursB[0], ValeursB[1]);
                println("Dommage retente ta chance !");
            } else {
                println("Bien joué !");
            }
            delay(5000);
        }
    }

    boolean sontLesMemes(MemoryGame[][] memory, int[] ValeursA, int[] ValeursB){
        boolean result = false;
        if(memory[ValeursA[0]][ValeursA[1]].planete==memory[ValeursB[0]][ValeursB[1]].planete){
            result = true;
        }
        return result;
    }

    void retournerCarte(MemoryGame[][] tab, int IDX_L, int IDX_C){
        tab[IDX_L][IDX_C].decouverte = true;
    }

    void cacherCarte(MemoryGame[][] tab, int IDX_L, int IDX_C){
        tab[IDX_L][IDX_C].decouverte = false;
    }

    int[] demandeCarte(MemoryGame[][] tab){
        int x = -1;
        int y = -1;
        boolean ValeurPossible = true;
        int[] result = new int[2];
        while(ValeurPossible){
            println("Donne la ligne de la carte : A B C ou D");
            x = readChar();
            if(x=='A'){
                x=0;
            } else if(x=='B'){
                x=1;
            } else if(x=='C'){
                x=2;
            } else {
                x=3;
            }
            println("Donne la colonne de la carte 1 2 3 ou 4");
            y = readInt()-1;
            if(x>=0 && x<=3 && y>=0 && y<=3){
                if(tab[x][y].decouverte==false){
                    ValeurPossible=false;
                }
            }
        }
        result[0] = x;
        result[1] = y;
        return result;
    }
}