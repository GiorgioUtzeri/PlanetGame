class test extends Program {
    void algorithm(){
        println(lireTxt("test.csv"));
        saveCSV(ajouterUtilisateur("Giorgio", 0, 26), "test.csv");
    }

    String[][] ajouterUtilisateur(String identifiant, int niveauActuel, int points){
        String[][] tab = new String[rowCount(loadCSV("test.csv"))+1][columnCount(loadCSV("test.csv"))];

        for(int IDX_LIGNE=0; IDX_LIGNE<rowCount(loadCSV("test.csv")); IDX_LIGNE++){
            for(int IDX_COL=0; IDX_COL<columnCount(loadCSV("test.csv")); IDX_COL++){
                tab[IDX_LIGNE][IDX_COL]=getCell(loadCSV("test.csv"), IDX_LIGNE, IDX_COL);
            }
        }

        tab[length(tab)-1][0]= identifiant;
        tab[length(tab)-1][1]= "" + niveauActuel;
        tab[length(tab)-1][2]= "" + points;
        return tab;
    }

    String lireTxt(String NomFichier){
        String result = "";
        for(int IDX_LIGNE=0; IDX_LIGNE<rowCount(loadCSV(NomFichier)); IDX_LIGNE++){
            result += getCell(loadCSV(NomFichier), IDX_LIGNE, 0) + '\n'; 
        }
        return result;
    }
}