class test extends Program{
    void algorithm(){
        String str = readString();
        println(testerStringToInt(str));
    }

    int testerStringToInt(String chaine){
        boolean possible = false;
        int result = -1;
        for(int i=0; i<length(chaine); i++){
            if(charAt(chaine, i)>='0' && charAt(chaine, i)<='9'){
                possible = true;
                println("bababab");
            } else {
                println("blabla");
                possible = false;
            }
        }
        if(possible){
            result = stringToInt(chaine);
        }
        return result;
    }
}