<Planet Game>
===========

Développé par <Giorgio UTZERI> <Noa LANNOY>
Contacts : <giorgio.utzeri.etu@univ-lille.fr> , <noa.lannoy.etu@univ-lille.fr>

# Présentation de <Planet Game>

<Description de votre jeu>
Le jeu se base sur plusieurs niveau de découverte de l’espace pour l’élève sous forme d’un « memory game ». Il devra alors trouver les positions commune de plusieurs planètes dans un tableau pour le premier niveau. Il devra ensuite au second niveau classer les planètes par rapport à leurs places par rapport au soleil. Le dernier niveau sera alors une suite de questions sur les planètes, l’élève gagne alors si il réussi les 3 niveaux.
Concernant le 1eme niveau usr l’affichage nous ferons un tableau avec les lignes a, b etc.. et les colonnes 1, 2 etc.. qui demandera donc une le placement d’une case plus d’une autre pour voir les affichés et voir si la réponse est bonne puis redemander etc..
Concernant le 2ème niveau sur l’affichage il sera présenter sur un système solaire fictif avec le soleil et les planètes manquante numérotés et le programme demandera un numéro pour placer une planète et si la réponse est bonne le numéro est remplacer par la planète le but est donc de remplacer tous les numéros sans faire d’erreur avec 3 essaies possible.

Des captures d'écran illustrant le fonctionnement du logiciel sont proposées dans le répertoire shots.


# Utilisation de <Planet Game>

Afin d'utiliser le projet, il suffit de taper les commandes suivantes dans un terminal :

```
./compile.sh
```
Permet la compilation des fichiers présents dans 'src' et création des fichiers '.class' dans 'classes'

```
./run.sh
```
Permet le lancement du jeu
