class MemoryGame{
    boolean decouverte;
    String planete;
}