class PlanetPlace{
    boolean decouverte;
    String planete;
    String distance;
}